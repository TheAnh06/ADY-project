"""
E-ComInsight: Data Visualization with Python
Project ADY201m  |  Stage 2 – All 4 Required Chart Types

Charts produced:
  Fig 1 – Line chart:        Monthly & quarterly revenue trend
  Fig 2 – Pie + Bar chart:   Payment method distribution
  Fig 3 – Geographical heatmap: Customer density by state (Brazil)
  Fig 4 – Boxplot:           Delivery time distribution by state

Requirements:
    pip install pandas sqlalchemy pymysql matplotlib seaborn folium

Run AFTER 05_analysis_python.py (uses same DB connection)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
from sqlalchemy import create_engine
import warnings
warnings.filterwarnings("ignore")

# ── DB connection ─────────────────────────────────────────────────────────────
DB_USER     = "root"
DB_PASSWORD = "hieu"
DB_HOST     = "127.0.0.1"
DB_PORT     = 3306
DB_NAME     = "olist_db"

engine = create_engine(
    f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    "?charset=utf8mb4"
)

# ── Shared style ──────────────────────────────────────────────────────────────
sns.set_theme(style="whitegrid", palette="muted", font_scale=1.1)
COLORS = {
    "primary":    "#4C72B0",
    "secondary":  "#DD8452",
    "accent":     "#55A868",
    "highlight":  "#C44E52",
    "neutral":    "#8172B2",
    "muted":      "#937860",
}
OUTPUT_DPI = 150


# ═════════════════════════════════════════════════════════════════════════════
# FIG 1 – LINE CHART: Monthly and quarterly revenue trend
# ═════════════════════════════════════════════════════════════════════════════

print("[1/4] Revenue trend line chart...")

revenue_monthly = pd.read_sql("""
    SELECT
        DATE_FORMAT(o.order_purchase_timestamp, '%%Y-%%m') AS `year_month`, 
        ROUND(SUM(p.payment_value), 2)                   AS total_revenue,
        COUNT(DISTINCT o.order_id)                        AS total_orders
    FROM olist_orders o
    JOIN olist_order_payments p ON o.order_id = p.order_id
    WHERE o.order_status = 'delivered'
      AND o.order_purchase_timestamp IS NOT NULL
    GROUP BY `year_month` -- Bọc dấu huyền ở đây
    ORDER BY `year_month` -- Bọc dấu huyền ở đây
""", engine)

revenue_monthly["year_month_dt"] = pd.to_datetime(
    revenue_monthly["year_month"], format="%Y-%m"
)

# Remove first and last partial months (data artifacts)
revenue_monthly = revenue_monthly.iloc[1:-1].reset_index(drop=True)

fig, axes = plt.subplots(2, 1, figsize=(14, 9), sharex=True)
fig.suptitle(
    "Olist – Revenue Trend (2016–2018)",
    fontsize=16, fontweight="bold", y=0.98
)

# Top panel: revenue
ax1 = axes[0]
ax1.plot(
    revenue_monthly["year_month_dt"],
    revenue_monthly["total_revenue"],
    color=COLORS["primary"], linewidth=2.5, marker="o", markersize=5,
    label="Monthly revenue (BRL)"
)
# 3-month rolling average
rolling = revenue_monthly["total_revenue"].rolling(3, center=True).mean()
ax1.plot(
    revenue_monthly["year_month_dt"], rolling,
    color=COLORS["secondary"], linewidth=2, linestyle="--", alpha=0.8,
    label="3-month rolling avg"
)
ax1.yaxis.set_major_formatter(
    mticker.FuncFormatter(lambda x, _: f"R$ {x/1_000:.0f}K")
)
ax1.set_ylabel("Total revenue (BRL)")
ax1.legend(loc="upper left")
ax1.set_title("Monthly revenue", fontsize=12)

# Shade the Nov 2017 peak (Black Friday)
peak_idx = revenue_monthly["total_revenue"].idxmax()
peak_dt  = revenue_monthly.loc[peak_idx, "year_month_dt"]
ax1.axvline(peak_dt, color=COLORS["highlight"], linewidth=1.5,
            linestyle=":", alpha=0.7)
ax1.annotate(
    f"Peak\n{peak_dt.strftime('%b %Y')}",
    xy=(peak_dt, revenue_monthly.loc[peak_idx, "total_revenue"]),
    xytext=(15, -20), textcoords="offset points",
    fontsize=9, color=COLORS["highlight"],
    arrowprops=dict(arrowstyle="->", color=COLORS["highlight"], lw=1.2)
)

# Bottom panel: order volume
ax2 = axes[1]
ax2.bar(
    revenue_monthly["year_month_dt"],
    revenue_monthly["total_orders"],
    color=COLORS["accent"], alpha=0.75, width=20,
    label="Monthly orders"
)
ax2.set_ylabel("Number of orders")
ax2.set_xlabel("Month")
ax2.legend(loc="upper left")
ax2.set_title("Monthly order volume", fontsize=12)

plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig("fig1_revenue_trend.png", dpi=OUTPUT_DPI, bbox_inches="tight")
plt.show()
print("  Saved: fig1_revenue_trend.png")


# ═════════════════════════════════════════════════════════════════════════════
# FIG 2 – PIE + HORIZONTAL BAR: Payment method distribution
# ═════════════════════════════════════════════════════════════════════════════

print("[2/4] Payment method chart...")

payment_dist = pd.read_sql("""
    SELECT
        payment_type,
        COUNT(*)                            AS n_transactions,
        ROUND(SUM(payment_value), 2)        AS total_value,
        ROUND(AVG(payment_value), 2)        AS avg_value
    FROM olist_order_payments
    WHERE payment_type != 'not_defined'
    GROUP BY payment_type
    ORDER BY n_transactions DESC
""", engine)

# Friendly labels
label_map = {
    "credit_card": "Credit card",
    "boleto":      "Boleto (cash bill)",
    "voucher":     "Voucher",
    "debit_card":  "Debit card",
}
payment_dist["label"] = payment_dist["payment_type"].map(label_map).fillna(
    payment_dist["payment_type"]
)

pie_colors = [COLORS["primary"], COLORS["secondary"],
              COLORS["accent"], COLORS["neutral"]]

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle(
    "Olist – Payment Method Analysis",
    fontsize=15, fontweight="bold"
)

# Left: Pie chart (transaction count share)
ax_pie = axes[0]
wedges, texts, autotexts = ax_pie.pie(
    payment_dist["n_transactions"],
    labels=payment_dist["label"],
    autopct="%1.1f%%",
    colors=pie_colors,
    startangle=90,
    wedgeprops={"edgecolor": "white", "linewidth": 1.5},
    textprops={"fontsize": 10},
)
for at in autotexts:
    at.set_fontsize(9)
    at.set_fontweight("bold")
ax_pie.set_title("Share of transactions", fontsize=12)

# Right: Horizontal bar (average order value)
ax_bar = axes[1]
bars = ax_bar.barh(
    payment_dist["label"],
    payment_dist["avg_value"],
    color=pie_colors,
    edgecolor="white",
    height=0.55,
)
ax_bar.set_xlabel("Average order value (BRL)")
ax_bar.set_title("Average order value by payment type", fontsize=12)
ax_bar.xaxis.set_major_formatter(
    mticker.FuncFormatter(lambda x, _: f"R$ {x:.0f}")
)
# Value labels inside bars
for bar, val in zip(bars, payment_dist["avg_value"]):
    ax_bar.text(
        bar.get_width() - 5, bar.get_y() + bar.get_height() / 2,
        f"R$ {val:.0f}",
        va="center", ha="right", fontsize=9, color="white", fontweight="bold"
    )

plt.tight_layout()
plt.savefig("fig2_payment_methods.png", dpi=OUTPUT_DPI, bbox_inches="tight")
plt.show()
print("  Saved: fig2_payment_methods.png")


# ═════════════════════════════════════════════════════════════════════════════
# FIG 3 – GEOGRAPHICAL HEATMAP: Customer density + revenue by state
# Two versions: Folium interactive map + Matplotlib static choropleth
# ═════════════════════════════════════════════════════════════════════════════

print("[3/4] Geographical heatmap...")

geo_data = pd.read_sql("""
    SELECT
        c.customer_state,
        COUNT(DISTINCT o.order_id)             AS total_orders,
        ROUND(SUM(p.payment_value), 2)          AS total_revenue,
        ROUND(AVG(p.payment_value), 2)          AS avg_order_value
    FROM olist_orders o
    JOIN olist_customers c      ON o.customer_id = c.customer_id
    JOIN olist_order_payments p ON o.order_id    = p.order_id
    WHERE o.order_status = 'delivered'
    GROUP BY c.customer_state
    ORDER BY total_orders DESC
""", engine)

# Brazilian state centroids (lat, lng) for heatmap markers
state_coords = {
    "AC": (-9.02,  -70.81), "AL": (-9.57,  -36.78), "AP": ( 1.41,  -51.77),
    "AM": (-3.07,  -61.66), "BA": (-12.97, -38.51), "CE": (-3.72,  -38.54),
    "DF": (-15.78, -47.93), "ES": (-19.19, -40.34), "GO": (-15.83, -49.84),
    "MA": (-2.55,  -44.30), "MT": (-12.64, -55.42), "MS": (-20.44, -54.65),
    "MG": (-19.82, -43.61), "PA": (-1.46,  -48.50), "PB": (-7.12,  -34.86),
    "PR": (-25.43, -49.27), "PE": (-8.05,  -34.88), "PI": (-5.09,  -42.80),
    "RJ": (-22.91, -43.17), "RN": (-5.79,  -35.21), "RS": (-30.03, -51.23),
    "RO": (-8.76,  -63.90), "RR": ( 2.82,  -60.67), "SC": (-27.60, -48.55),
    "SP": (-23.55, -46.63), "SE": (-10.90, -37.07), "TO": (-10.25, -48.25),
}

geo_data["lat"] = geo_data["customer_state"].map(lambda s: state_coords.get(s, (0,0))[0])
geo_data["lng"] = geo_data["customer_state"].map(lambda s: state_coords.get(s, (0,0))[1])

# --- 3a. Folium interactive heatmap (HTML output) ----------------------------
try:
    import folium
    from folium.plugins import HeatMap

    m = folium.Map(location=[-15.0, -50.0], zoom_start=4, tiles="CartoDB positron")

    # Heat layer weighted by order volume
    heat_data = [
        [row["lat"], row["lng"], row["total_orders"]]
        for _, row in geo_data.iterrows()
        if row["lat"] != 0
    ]
    HeatMap(heat_data, radius=30, blur=20, max_zoom=6).add_to(m)

    # Circle markers with popup
    for _, row in geo_data.iterrows():
        if row["lat"] == 0:
            continue
        folium.CircleMarker(
            location=[row["lat"], row["lng"]],
            radius=max(5, min(30, row["total_orders"] / 1000)),
            color=COLORS["primary"],
            fill=True,
            fill_opacity=0.6,
            popup=folium.Popup(
                f"<b>{row['customer_state']}</b><br>"
                f"Orders: {row['total_orders']:,}<br>"
                f"Revenue: R$ {row['total_revenue']:,.0f}<br>"
                f"Avg order: R$ {row['avg_order_value']:.0f}",
                max_width=200
            ),
        ).add_to(m)

    m.save("fig3_geo_heatmap.html")
    print("  Saved: fig3_geo_heatmap.html (interactive – open in browser)")
except ImportError:
    print("  folium not installed – skipping interactive map. Run: pip install folium")

# --- 3b. Matplotlib static bubble chart (always produced) --------------------
fig, ax = plt.subplots(figsize=(10, 9))
fig.suptitle(
    "Olist – Customer Orders by Brazilian State",
    fontsize=15, fontweight="bold"
)

sc = ax.scatter(
    geo_data["lng"],
    geo_data["lat"],
    s=geo_data["total_orders"] / 15,   # bubble size proportional to orders
    c=geo_data["total_revenue"],
    cmap="YlOrRd",
    alpha=0.75,
    edgecolors="grey",
    linewidth=0.5,
)

# State labels
for _, row in geo_data.iterrows():
    if row["lat"] != 0:
        ax.text(
            row["lng"] + 0.5, row["lat"] + 0.3,
            row["customer_state"],
            fontsize=8, ha="left", va="bottom", color="#333333"
        )

cbar = plt.colorbar(sc, ax=ax, shrink=0.7)
cbar.set_label("Total revenue (BRL)", fontsize=10)
cbar.formatter = mticker.FuncFormatter(lambda x, _: f"R$ {x/1_000:.0f}K")
cbar.update_ticks()

ax.set_xlabel("Longitude")
ax.set_ylabel("Latitude")
ax.set_title(
    "Bubble size = order volume  |  Color = total revenue",
    fontsize=10, color="grey"
)
ax.set_xlim(-75, -34)
ax.set_ylim(-35, 6)

plt.tight_layout()
plt.savefig("fig3_geo_bubble.png", dpi=OUTPUT_DPI, bbox_inches="tight")
plt.show()
print("  Saved: fig3_geo_bubble.png")


# ═════════════════════════════════════════════════════════════════════════════
# FIG 4 – BOXPLOT: Delivery time distribution by state
# ═════════════════════════════════════════════════════════════════════════════

print("[4/4] Delivery time boxplot...")

delivery_raw = pd.read_sql("""
    SELECT
        c.customer_state,
        DATEDIFF(o.order_delivered_customer_date,
                 o.order_purchase_timestamp)          AS delivery_days,
        DATEDIFF(o.order_delivered_customer_date,
                 o.order_estimated_delivery_date)     AS delay_days
    FROM olist_orders o
    JOIN olist_customers c ON o.customer_id = c.customer_id
    WHERE o.order_status = 'delivered'
      AND o.order_delivered_customer_date IS NOT NULL
      AND o.order_purchase_timestamp IS NOT NULL
""", engine)

# Remove extreme outliers (> 120 days)
delivery_raw = delivery_raw[
    (delivery_raw["delivery_days"] > 0) &
    (delivery_raw["delivery_days"] <= 120)
]

# Order states by median delivery time (slowest at top)
state_order = (
    delivery_raw.groupby("customer_state")["delivery_days"]
    .median()
    .sort_values(ascending=False)
    .index.tolist()
)

# Only show states with >= 100 orders for clarity
valid_states = (
    delivery_raw["customer_state"].value_counts()
    [lambda x: x >= 100].index.tolist()
)
delivery_plot = delivery_raw[delivery_raw["customer_state"].isin(valid_states)].copy()
state_order   = [s for s in state_order if s in valid_states]

# Color boxes: red = avg delay > 0 (late), green = avg delay <= 0 (early)
state_delay = delivery_plot.groupby("customer_state")["delay_days"].mean()
palette = {
    s: COLORS["highlight"] if state_delay.get(s, 0) > 0 else COLORS["accent"]
    for s in state_order
}

fig, ax = plt.subplots(figsize=(16, 9))
fig.suptitle(
    "Olist – Delivery Time by Customer State",
    fontsize=15, fontweight="bold"
)

sns.boxplot(
    data=delivery_plot,
    x="delivery_days",
    y="customer_state",
    order=state_order,
    palette=palette,
    flierprops={"marker": ".", "markersize": 3, "alpha": 0.3},
    width=0.6,
    ax=ax,
)

# Reference line: overall median
overall_median = delivery_plot["delivery_days"].median()
ax.axvline(
    overall_median, color="navy", linewidth=1.5,
    linestyle="--", alpha=0.6, label=f"Overall median = {overall_median:.0f} days"
)

ax.set_xlabel("Delivery time (days from purchase to receipt)", fontsize=11)
ax.set_ylabel("Customer state (sorted by median, slowest first)", fontsize=11)
ax.legend(loc="lower right", fontsize=10)

# Add custom legend for box colors
from matplotlib.patches import Patch
legend_patches = [
    Patch(facecolor=COLORS["highlight"], label="Avg delay > 0 (late on average)"),
    Patch(facecolor=COLORS["accent"],    label="Avg delay <= 0 (on time or early)"),
]
ax.legend(handles=legend_patches + [
    plt.Line2D([0], [0], color="navy", linewidth=1.5, linestyle="--",
               label=f"Overall median = {overall_median:.0f} days")
], loc="lower right", fontsize=9)

plt.tight_layout()
plt.savefig("fig4_delivery_boxplot.png", dpi=OUTPUT_DPI, bbox_inches="tight")
plt.show()
print("  Saved: fig4_delivery_boxplot.png")

print("\n  All 4 visualizations complete.")
print("  Output files:")
print("    fig1_revenue_trend.png")
print("    fig2_payment_methods.png")
print("    fig3_geo_heatmap.html  (interactive)")
print("    fig3_geo_bubble.png    (static)")
print("    fig4_delivery_boxplot.png")
