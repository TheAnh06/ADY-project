"""
E-ComInsight: Data Analysis with Python
Project ADY201m  |  Stage 2 – EDA & Statistical Analysis

Sections:
  1. Connect to MySQL and load data
  2. Data cleaning (Pandas)
  3. Descriptive statistics
  4. ANOVA – delivery time across states
  5. Chi-Square – payment type vs order status
  6. RFM feature engineering (preparation for Stage 3 ML)

Requirements:
    pip install pandas sqlalchemy pymysql scipy matplotlib seaborn
"""

# ── 1. IMPORTS & DB CONNECTION ───────────────────────────────────────────────

import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from scipy import stats
import warnings
warnings.filterwarnings("ignore")

# ── Edit DB credentials ──────────────────────────────────────────────────────
DB_USER     = "root"
DB_PASSWORD = "hieu"
DB_HOST     = "127.0.0.1"
DB_PORT     = 3306
DB_NAME     = "olist_db"

engine = create_engine(
    f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    "?charset=utf8mb4"
)
print("Connected to MySQL:", DB_NAME)


# ── 2. LOAD TABLES FROM DATABASE ─────────────────────────────────────────────

print("\n[1/6] Loading tables...")

orders = pd.read_sql("""
    SELECT order_id, customer_id, order_status,
           order_purchase_timestamp,
           order_delivered_customer_date,
           order_estimated_delivery_date
    FROM olist_orders
""", engine, parse_dates=[
    "order_purchase_timestamp",
    "order_delivered_customer_date",
    "order_estimated_delivery_date"
])

customers = pd.read_sql(
    "SELECT customer_id, customer_unique_id, customer_state FROM olist_customers",
    engine
)

payments = pd.read_sql(
    "SELECT order_id, payment_type, payment_installments, payment_value FROM olist_order_payments",
    engine
)

reviews = pd.read_sql(
    "SELECT order_id, review_score FROM olist_order_reviews WHERE review_score IS NOT NULL",
    engine
)

items = pd.read_sql(
    "SELECT order_id, product_id, seller_id, price, freight_value FROM olist_order_items",
    engine
)

products = pd.read_sql("""
    SELECT p.product_id,
           COALESCE(t.product_category_name_english, 'unknown') AS category,
           p.product_weight_g, p.product_length_cm,
           p.product_height_cm, p.product_width_cm
    FROM olist_products p
    LEFT JOIN product_category_name_translation t
           ON p.product_category_name = t.product_category_name
""", engine)

print(f"  orders:    {len(orders):>7,} rows")
print(f"  customers: {len(customers):>7,} rows")
print(f"  payments:  {len(payments):>7,} rows")
print(f"  reviews:   {len(reviews):>7,} rows")
print(f"  items:     {len(items):>7,} rows")
print(f"  products:  {len(products):>7,} rows")


# ── 3. DATA CLEANING (Pandas) ─────────────────────────────────────────────────

print("\n[2/6] Cleaning data...")

# --- 3a. Orders: keep delivered only, remove rows with missing dates ----------
print(f"  Orders before filter: {len(orders):,}")
orders_delivered = orders[orders["order_status"] == "delivered"].copy()
print(f"  Delivered orders:     {len(orders_delivered):,}")

# Drop rows where delivery date is missing (orders not yet completed)
orders_delivered.dropna(
    subset=["order_delivered_customer_date", "order_purchase_timestamp"],
    inplace=True
)
print(f"  After dropping null delivery dates: {len(orders_delivered):,}")

# --- 3b. Compute delivery KPIs -----------------------------------------------
orders_delivered["delivery_time_days"] = (
    orders_delivered["order_delivered_customer_date"]
    - orders_delivered["order_purchase_timestamp"]
).dt.days

orders_delivered["delay_days"] = (
    orders_delivered["order_delivered_customer_date"]
    - orders_delivered["order_estimated_delivery_date"]
).dt.days

orders_delivered["is_late"] = (orders_delivered["delay_days"] > 0).astype(int)

# Remove extreme outliers: delivery > 120 days (likely data errors)
before = len(orders_delivered)
orders_delivered = orders_delivered[orders_delivered["delivery_time_days"] <= 120]
print(f"  Removed {before - len(orders_delivered)} extreme delivery outliers (>120 days)")

# --- 3c. Products: median imputation for physical dimensions -----------------
physical_cols = [
    "product_weight_g", "product_length_cm",
    "product_height_cm", "product_width_cm"
]
for col in physical_cols:
    null_count = products[col].isna().sum()
    if null_count > 0:
        median_val = products[col].median()
        products[col].fillna(median_val, inplace=True)
        print(f"  Imputed {null_count} NULLs in {col} with median={median_val:.2f}")

# Flag unknown category (already set to 'unknown' in SQL query)
unknown_count = (products["category"] == "unknown").sum()
print(f"  Products with unknown category: {unknown_count}")

# --- 3d. Payments: remove zero-value transactions ----------------------------
before = len(payments)
payments = payments[payments["payment_value"] > 0].copy()
print(f"  Removed {before - len(payments)} zero-value payment rows")

# --- 3e. Aggregate payments per order (some orders have multiple payment rows)
payments_agg = payments.groupby("order_id").agg(
    payment_type    = ("payment_type", lambda x: x.value_counts().index[0]),  # dominant type
    total_paid      = ("payment_value", "sum"),
    max_installments= ("payment_installments", "max")
).reset_index()


# ── 4. DESCRIPTIVE STATISTICS ────────────────────────────────────────────────

print("\n[3/6] Descriptive statistics...")

# --- 4a. Full joined analysis table ------------------------------------------
df = (
    orders_delivered
    .merge(customers,    on="customer_id", how="left")
    .merge(payments_agg, on="order_id",    how="left")
    .merge(reviews,      on="order_id",    how="left")
)

print("\n  Delivery time summary (days):")
print(df["delivery_time_days"].describe().round(2).to_string())

print("\n  Delay days summary (+ = late, - = early):")
print(df["delay_days"].describe().round(2).to_string())

print(f"\n  Late delivery rate: {df['is_late'].mean()*100:.1f}%")

print("\n  Review score distribution:")
print(df["review_score"].value_counts().sort_index().to_string())

print("\n  Payment type distribution:")
print(df["payment_type"].value_counts().to_string())


# ── 5. ANOVA – Delivery time across states ───────────────────────────────────
# H0: Mean delivery time is the same across all Brazilian states
# H1: At least one state has a significantly different mean delivery time

print("\n[4/6] ANOVA – delivery time by customer state...")

# Keep only states with at least 30 orders (enough for statistical power)
state_counts = df.groupby("customer_state")["delivery_time_days"].count()
valid_states  = state_counts[state_counts >= 30].index
df_anova      = df[df["customer_state"].isin(valid_states)]

state_groups = [
    group["delivery_time_days"].dropna().values
    for _, group in df_anova.groupby("customer_state")
]

f_stat, p_value = stats.f_oneway(*state_groups)

print(f"  States included:   {len(valid_states)}")
print(f"  F-statistic:       {f_stat:.4f}")
print(f"  p-value:           {p_value:.2e}")

if p_value < 0.05:
    print("  Result: REJECT H0 — delivery time differs significantly across states (p < 0.05)")
else:
    print("  Result: FAIL TO REJECT H0 — no significant difference (p >= 0.05)")

# Top 5 slowest and fastest states
state_mean = df_anova.groupby("customer_state")["delivery_time_days"].mean().sort_values()
print("\n  5 fastest delivery states (avg days):")
print(state_mean.head(5).round(1).to_string())
print("\n  5 slowest delivery states (avg days):")
print(state_mean.tail(5).round(1).to_string())


# ── 6. CHI-SQUARE – Payment type vs Order status ─────────────────────────────
# H0: Payment type and order status are independent
# H1: There is a significant association between them

print("\n[5/6] Chi-Square – payment type vs order status...")

df_chi = (
    orders
    .merge(payments[["order_id", "payment_type"]], on="order_id", how="inner")
    [["order_status", "payment_type"]]
    .dropna()
)

# Filter to main statuses only
main_statuses  = ["delivered", "canceled", "shipped", "processing"]
main_payments  = ["credit_card", "boleto", "voucher", "debit_card"]
df_chi = df_chi[
    df_chi["order_status"].isin(main_statuses) &
    df_chi["payment_type"].isin(main_payments)
]

contingency = pd.crosstab(df_chi["payment_type"], df_chi["order_status"])
print("\n  Contingency table:")
print(contingency.to_string())

chi2, p_chi, dof, expected = stats.chi2_contingency(contingency)
print(f"\n  Chi-square statistic: {chi2:.4f}")
print(f"  Degrees of freedom:   {dof}")
print(f"  p-value:              {p_chi:.2e}")

if p_chi < 0.05:
    print("  Result: REJECT H0 — payment type IS significantly associated with order status")
else:
    print("  Result: FAIL TO REJECT H0 — no significant association found")


# ── 7. RFM FEATURE ENGINEERING (Stage 3 preparation) ────────────────────────

print("\n[6/6] Computing RFM features...")

# Snapshot date = 1 day after the last recorded purchase
snapshot_date = orders_delivered["order_purchase_timestamp"].max() + pd.Timedelta(days=1)
print(f"  Snapshot date: {snapshot_date.date()}")

# Merge order-level data for RFM
rfm_base = (
    orders_delivered[["order_id", "customer_id", "order_purchase_timestamp"]]
    .merge(payments_agg[["order_id", "total_paid"]], on="order_id", how="left")
    .merge(customers[["customer_id", "customer_unique_id"]], on="customer_id", how="left")
)

rfm = rfm_base.groupby("customer_unique_id").agg(
    Recency   = ("order_purchase_timestamp",
                 lambda x: (snapshot_date - x.max()).days),
    Frequency = ("order_id",    "count"),
    Monetary  = ("total_paid",  "sum")
).reset_index()

rfm["Monetary"] = rfm["Monetary"].round(2)

print("\n  RFM summary statistics:")
print(rfm[["Recency", "Frequency", "Monetary"]].describe().round(2).to_string())

# Save RFM table for Stage 3 ML
rfm.to_csv("rfm_features.csv", index=False)
print(f"\n  Saved rfm_features.csv  ({len(rfm):,} customers)")
print("\n  EDA complete. Run 05_visualization.py next.")
