-- ============================================================
-- E-ComInsight: Data Analysis with SQL
-- Project ADY201m  |  Stage 2 – SQL Analysis
-- Run against olist_db after ELT pipeline completes
-- ============================================================

USE olist_db;

-- ============================================================
-- SECTION A: Revenue Trend Analysis
-- Objective: Detect peak shopping cycles by month and quarter
-- ============================================================

-- A1. Monthly revenue trend (2016–2018)
SELECT
    DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m')  AS order_year_month,
    COUNT(DISTINCT o.order_id)                        AS total_orders,
    ROUND(SUM(p.payment_value), 2)                    AS total_revenue,
    ROUND(AVG(p.payment_value), 2)                    AS avg_order_value
FROM olist_orders o
JOIN olist_order_payments p ON o.order_id = p.order_id
WHERE o.order_status = 'delivered'
  AND o.order_purchase_timestamp IS NOT NULL
GROUP BY order_year_month
ORDER BY order_year_month;

-- A2. Quarterly revenue breakdown
SELECT
    YEAR(o.order_purchase_timestamp)                  AS year,
    QUARTER(o.order_purchase_timestamp)               AS quarter,
    COUNT(DISTINCT o.order_id)                        AS total_orders,
    ROUND(SUM(p.payment_value), 2)                    AS total_revenue
FROM olist_orders o
JOIN olist_order_payments p ON o.order_id = p.order_id
WHERE o.order_status = 'delivered'
  AND o.order_purchase_timestamp IS NOT NULL
GROUP BY year, quarter
ORDER BY year, quarter;

-- A3. Top 10 product categories by total revenue
SELECT
    COALESCE(t.product_category_name_english, 'Unknown') AS category,
    COUNT(DISTINCT oi.order_id)                          AS total_orders,
    ROUND(SUM(oi.price), 2)                              AS total_revenue,
    ROUND(AVG(oi.price), 2)                              AS avg_item_price
FROM olist_order_items oi
JOIN olist_products pr      ON oi.product_id = pr.product_id
LEFT JOIN product_category_name_translation t
                            ON pr.product_category_name = t.product_category_name
JOIN olist_orders o         ON oi.order_id = o.order_id
WHERE o.order_status = 'delivered'
GROUP BY category
ORDER BY total_revenue DESC
LIMIT 10;


-- ============================================================
-- SECTION B: Payment Method Analysis
-- Objective: Understand consumer payment preferences
-- ============================================================

-- B1. Payment type distribution (count + percentage)
SELECT
    payment_type,
    COUNT(*)                                            AS n_transactions,
    ROUND(SUM(payment_value), 2)                        AS total_value,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct_transactions,
    ROUND(AVG(payment_value), 2)                        AS avg_payment_value,
    ROUND(AVG(payment_installments), 2)                 AS avg_installments
FROM olist_order_payments
GROUP BY payment_type
ORDER BY n_transactions DESC;

-- B2. Credit card installment distribution
-- Tests Hypothesis 3: long-installment buyers spend more
SELECT
    payment_installments,
    COUNT(*)                           AS n_orders,
    ROUND(AVG(payment_value), 2)       AS avg_order_value,
    ROUND(SUM(payment_value), 2)       AS total_revenue
FROM olist_order_payments
WHERE payment_type = 'credit_card'
GROUP BY payment_installments
ORDER BY payment_installments;

-- B3. Average order value: credit_card (>6 installments) vs boleto/debit_card
-- Direct test of Hypothesis 3 (>50% higher AOV expected)
SELECT
    CASE
        WHEN payment_type = 'credit_card' AND payment_installments > 6 THEN 'Credit card >6 installments'
        WHEN payment_type = 'credit_card'                              THEN 'Credit card <=6 installments'
        WHEN payment_type = 'boleto'                                   THEN 'Boleto (cash bill)'
        WHEN payment_type = 'debit_card'                               THEN 'Debit card'
        ELSE payment_type
    END                                AS payment_group,
    COUNT(*)                           AS n_transactions,
    ROUND(AVG(payment_value), 2)       AS avg_order_value,
    ROUND(MIN(payment_value), 2)       AS min_value,
    ROUND(MAX(payment_value), 2)       AS max_value
FROM olist_order_payments
WHERE payment_type IN ('credit_card', 'boleto', 'debit_card')
GROUP BY payment_group
ORDER BY avg_order_value DESC;


-- ============================================================
-- SECTION C: Logistics & Delivery Time Analysis
-- Objective: Identify states with delivery bottlenecks
-- Uses Window Functions for ranking
-- ============================================================

-- C1. Actual vs estimated delivery time per state
-- delivery_time_days: actual days from purchase to delivery
-- delay_days: positive = late, negative = early
SELECT
    c.customer_state,
    COUNT(o.order_id)                                        AS total_orders,
    ROUND(AVG(
        DATEDIFF(o.order_delivered_customer_date,
                 o.order_purchase_timestamp)), 1)            AS avg_delivery_days,
    ROUND(AVG(
        DATEDIFF(o.order_delivered_customer_date,
                 o.order_estimated_delivery_date)), 1)       AS avg_delay_days,
    SUM(CASE WHEN o.order_delivered_customer_date
                  > o.order_estimated_delivery_date
             THEN 1 ELSE 0 END)                             AS late_orders,
    ROUND(SUM(CASE WHEN o.order_delivered_customer_date
                        > o.order_estimated_delivery_date
                   THEN 1 ELSE 0 END) * 100.0
          / COUNT(o.order_id), 2)                           AS late_pct
FROM olist_orders o
JOIN olist_customers c ON o.customer_id = c.customer_id
WHERE o.order_status = 'delivered'
  AND o.order_delivered_customer_date IS NOT NULL
  AND o.order_estimated_delivery_date IS NOT NULL
GROUP BY c.customer_state
ORDER BY avg_delay_days DESC;

-- C2. Delivery time ranked by state using Window Function
-- Supports Boxplot visualization in Python
WITH state_delivery AS (
    SELECT
        c.customer_state,
        DATEDIFF(o.order_delivered_customer_date,
                 o.order_purchase_timestamp)         AS delivery_days,
        DATEDIFF(o.order_delivered_customer_date,
                 o.order_estimated_delivery_date)    AS delay_days
    FROM olist_orders o
    JOIN olist_customers c ON o.customer_id = c.customer_id
    WHERE o.order_status = 'delivered'
      AND o.order_delivered_customer_date IS NOT NULL
)
SELECT
    customer_state,
    delivery_days,
    delay_days,
    AVG(delivery_days) OVER (PARTITION BY customer_state)  AS state_avg_days,
    RANK()             OVER (ORDER BY delivery_days DESC)   AS rank_slowest
FROM state_delivery
ORDER BY customer_state, delivery_days;

-- C3. ANOVA preparation: delivery time stats per state
-- Export this result to R or Python for ANOVA test
SELECT
    c.customer_state                                                AS state,
    COUNT(*)                                                        AS n,
    ROUND(AVG(DATEDIFF(o.order_delivered_customer_date,
                       o.order_purchase_timestamp)), 2)             AS mean_days,
    ROUND(STDDEV(DATEDIFF(o.order_delivered_customer_date,
                          o.order_purchase_timestamp)), 2)          AS std_days,
    ROUND(MIN(DATEDIFF(o.order_delivered_customer_date,
                       o.order_purchase_timestamp)), 0)             AS min_days,
    ROUND(MAX(DATEDIFF(o.order_delivered_customer_date,
                       o.order_purchase_timestamp)), 0)             AS max_days
FROM olist_orders o
JOIN olist_customers c ON o.customer_id = c.customer_id
WHERE o.order_status = 'delivered'
  AND o.order_delivered_customer_date IS NOT NULL
GROUP BY c.customer_state
HAVING n >= 30                   -- only states with enough data for ANOVA
ORDER BY mean_days DESC;


-- ============================================================
-- SECTION D: Review Score vs Late Delivery
-- Objective: Test Hypothesis 1 (late orders get 3× more 1–2 star reviews)
-- ============================================================

-- D1. Review score distribution: on-time vs late orders
SELECT
    CASE
        WHEN o.order_delivered_customer_date <= o.order_estimated_delivery_date
            THEN 'On time or early'
        ELSE 'Late'
    END                                                        AS delivery_status,
    r.review_score,
    COUNT(*)                                                   AS n_reviews,
    ROUND(COUNT(*) * 100.0 /
          SUM(COUNT(*)) OVER (
              PARTITION BY
                  CASE WHEN o.order_delivered_customer_date
                            <= o.order_estimated_delivery_date
                       THEN 'On time or early' ELSE 'Late' END
          ), 2)                                                AS pct_within_group
FROM olist_orders o
JOIN olist_order_reviews r ON o.order_id = r.order_id
WHERE o.order_status = 'delivered'
  AND o.order_delivered_customer_date IS NOT NULL
  AND o.order_estimated_delivery_date IS NOT NULL
  AND r.review_score IS NOT NULL
GROUP BY delivery_status, r.review_score
ORDER BY delivery_status, r.review_score;

-- D2. Low-score rate multiplier (direct test of Hypothesis 1: 3× claim)
SELECT
    delivery_status,
    low_score_pct,
    ROUND(low_score_pct /
          MIN(low_score_pct) OVER (), 2)  AS multiplier_vs_best
FROM (
    SELECT
        CASE WHEN o.order_delivered_customer_date
                  <= o.order_estimated_delivery_date
             THEN 'On time or early' ELSE 'Late'
        END                                                    AS delivery_status,
        ROUND(SUM(CASE WHEN r.review_score <= 2 THEN 1 ELSE 0 END)
              * 100.0 / COUNT(*), 2)                           AS low_score_pct
    FROM olist_orders o
    JOIN olist_order_reviews r ON o.order_id = r.order_id
    WHERE o.order_status = 'delivered'
      AND o.order_delivered_customer_date IS NOT NULL
      AND r.review_score IS NOT NULL
    GROUP BY delivery_status
) sub
ORDER BY low_score_pct DESC;


-- ============================================================
-- SECTION E: Geographic Market Analysis
-- Objective: Test Hypothesis 2 (São Paulo > 40% of orders & revenue)
-- ============================================================

-- E1. Orders and revenue by customer state
SELECT
    c.customer_state,
    COUNT(DISTINCT o.order_id)                                  AS total_orders,
    ROUND(SUM(p.payment_value), 2)                              AS total_revenue,
    ROUND(COUNT(DISTINCT o.order_id) * 100.0
          / SUM(COUNT(DISTINCT o.order_id)) OVER (), 2)         AS pct_orders,
    ROUND(SUM(p.payment_value) * 100.0
          / SUM(SUM(p.payment_value)) OVER (), 2)               AS pct_revenue
FROM olist_orders o
JOIN olist_customers c       ON o.customer_id = c.customer_id
JOIN olist_order_payments p  ON o.order_id    = p.order_id
WHERE o.order_status = 'delivered'
GROUP BY c.customer_state
ORDER BY total_orders DESC;

-- E2. Seller distribution by state
SELECT
    seller_state,
    COUNT(*)                                                    AS n_sellers,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2)         AS pct_sellers
FROM olist_sellers
GROUP BY seller_state
ORDER BY n_sellers DESC
LIMIT 10;

-- E3. Cross-state orders: customer state vs seller state
-- Reveals inter-state logistics routes that drive delivery time
SELECT
    c.customer_state,
    s.seller_state,
    COUNT(*)                                                   AS n_orders,
    ROUND(AVG(DATEDIFF(o.order_delivered_customer_date,
                       o.order_purchase_timestamp)), 1)        AS avg_delivery_days
FROM olist_orders o
JOIN olist_customers   c  ON o.customer_id  = c.customer_id
JOIN olist_order_items oi ON o.order_id     = oi.order_id
JOIN olist_sellers     s  ON oi.seller_id   = s.seller_id
WHERE o.order_status = 'delivered'
  AND o.order_delivered_customer_date IS NOT NULL
GROUP BY c.customer_state, s.seller_state
HAVING n_orders >= 100
ORDER BY avg_delivery_days DESC
LIMIT 20;
