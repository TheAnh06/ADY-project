-- ============================================================
-- E-ComInsight – Post-Load Verification Queries
-- Project ADY201m  |  Stage 1 – Verification
-- Run after 02_elt_pipeline.py completes successfully
-- ============================================================

USE olist_db;

-- ── 1. Row counts per table ──────────────────────────────────
-- Expected values based on official Olist dataset:
--   olist_customers              → 99,441
--   olist_orders                 → 99,441
--   olist_order_items            → 112,650
--   olist_order_payments         → 103,886
--   olist_order_reviews          → 99,224
--   olist_products               → 32,951
--   olist_sellers                → 3,095
--   olist_geolocation            → 1,000,163
--   product_category_translation → 71

SELECT
    table_name                              AS `Table`,
    table_rows                              AS `Approx Rows (InnoDB estimate)`,
    ROUND(data_length / 1024 / 1024, 2)     AS `Data (MB)`,
    ROUND(index_length / 1024 / 1024, 2)    AS `Index (MB)`
FROM   information_schema.tables
WHERE  table_schema = 'olist_db'
ORDER  BY table_rows DESC;

-- ── 2. Exact row counts (slower but accurate) ────────────────
SELECT 'olist_customers'               AS tbl, COUNT(*) AS n FROM olist_customers
UNION ALL
SELECT 'olist_orders',                          COUNT(*) FROM olist_orders
UNION ALL
SELECT 'olist_order_items',                     COUNT(*) FROM olist_order_items
UNION ALL
SELECT 'olist_order_payments',                  COUNT(*) FROM olist_order_payments
UNION ALL
SELECT 'olist_order_reviews',                   COUNT(*) FROM olist_order_reviews
UNION ALL
SELECT 'olist_products',                        COUNT(*) FROM olist_products
UNION ALL
SELECT 'olist_sellers',                         COUNT(*) FROM olist_sellers
UNION ALL
SELECT 'olist_geolocation',                     COUNT(*) FROM olist_geolocation
UNION ALL
SELECT 'product_category_name_translation',     COUNT(*) FROM product_category_name_translation;

-- ── 3. FK integrity checks ───────────────────────────────────
-- Any non-zero result means orphaned rows exist (bad FK relationship)

-- Orders without a matching customer
SELECT 'orders → customers (orphans)' AS check_name,
       COUNT(*) AS orphan_count
FROM   olist_orders o
WHERE  o.customer_id IS NOT NULL
  AND  o.customer_id NOT IN (SELECT customer_id FROM olist_customers);

-- Order items without a matching order
SELECT 'order_items → orders (orphans)' AS check_name,
       COUNT(*) AS orphan_count
FROM   olist_order_items i
WHERE  i.order_id NOT IN (SELECT order_id FROM olist_orders);

-- Order payments without a matching order
SELECT 'order_payments → orders (orphans)' AS check_name,
       COUNT(*) AS orphan_count
FROM   olist_order_payments p
WHERE  p.order_id NOT IN (SELECT order_id FROM olist_orders);

-- Order reviews without a matching order
SELECT 'order_reviews → orders (orphans)' AS check_name,
       COUNT(*) AS orphan_count
FROM   olist_order_reviews r
WHERE  r.order_id IS NOT NULL
  AND  r.order_id NOT IN (SELECT order_id FROM olist_orders);

-- Order items without a matching product
SELECT 'order_items → products (orphans)' AS check_name,
       COUNT(*) AS orphan_count
FROM   olist_order_items i
WHERE  i.product_id IS NOT NULL
  AND  i.product_id NOT IN (SELECT product_id FROM olist_products);

-- ── 4. NULL audit – columns that should NOT be null ─────────
SELECT 'orders with NULL order_id'   AS check_name, COUNT(*) AS cnt FROM olist_orders   WHERE order_id   IS NULL
UNION ALL
SELECT 'customers with NULL cust_id',               COUNT(*) FROM olist_customers WHERE customer_id IS NULL
UNION ALL
SELECT 'products with NULL prod_id',                COUNT(*) FROM olist_products  WHERE product_id  IS NULL
UNION ALL
SELECT 'sellers with NULL seller_id',               COUNT(*) FROM olist_sellers   WHERE seller_id   IS NULL;

-- ── 5. Date range sanity check ───────────────────────────────
-- Orders should fall between 2016 and 2018
SELECT
    MIN(order_purchase_timestamp)  AS earliest_order,
    MAX(order_purchase_timestamp)  AS latest_order,
    COUNT(*)                       AS total_orders,
    SUM(CASE WHEN order_purchase_timestamp IS NULL THEN 1 ELSE 0 END) AS null_dates
FROM olist_orders;

-- ── 6. Payment type distribution ────────────────────────────
SELECT
    payment_type,
    COUNT(*)                            AS n_transactions,
    ROUND(COUNT(*) * 100.0 /
          SUM(COUNT(*)) OVER (), 2)     AS pct
FROM   olist_order_payments
GROUP  BY payment_type
ORDER  BY n_transactions DESC;

-- ── 7. Review score distribution ────────────────────────────
SELECT
    review_score,
    COUNT(*)                            AS n_reviews,
    ROUND(COUNT(*) * 100.0 /
          SUM(COUNT(*)) OVER (), 2)     AS pct
FROM   olist_order_reviews
WHERE  review_score IS NOT NULL
GROUP  BY review_score
ORDER  BY review_score;

-- ── 8. Top 5 customer states ─────────────────────────────────
SELECT
    customer_state,
    COUNT(*) AS n_customers
FROM   olist_customers
GROUP  BY customer_state
ORDER  BY n_customers DESC
LIMIT  5;