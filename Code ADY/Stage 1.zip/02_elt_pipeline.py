"""
E-ComInsight – Python ELT Pipeline
Project ADY201m  |  Stage 1 – Automated Data Loading

Requirements:
    pip install pandas sqlalchemy pymysql tqdm

Usage:
    1. Edit the CONFIG section below (DB credentials + CSV folder path).
    2. Run:  python 02_elt_pipeline.py
    3. The script loads all 9 tables in dependency order.
       FK checks are disabled during loading and re-enabled afterwards.
"""

import os
import time
import logging
import pandas as pd
from sqlalchemy import create_engine, text
from tqdm import tqdm

# ============================================================
#  CONFIG – edit these before running
# ============================================================
DB_USER     = "root"           # your MySQL username
DB_PASSWORD = "hieu"  # your MySQL password
DB_HOST     = "127.0.0.1"
DB_PORT     = 3306
DB_NAME     = "olist_db"

# Folder that contains all 9 CSV files (use forward slashes or raw string)
CSV_FOLDER  = r"C:\Users\This Pc\OneDrive\Documents\ADY201m\Project"

CHUNK_SIZE  = 50_000   # rows per batch – reduce to 10 000 on low-RAM machines
# ============================================================

# ── Logging setup ──────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("elt_pipeline.log", encoding="utf-8"),
    ],
)
log = logging.getLogger(__name__)


# ============================================================
#  TABLE DEFINITIONS
#  Each entry: (csv_filename, mysql_table_name, column_renames, date_columns)
#
#  column_renames  – dict of {csv_col: db_col} for typo corrections
#  date_columns    – list of columns to parse as datetime
# ============================================================
TABLE_CONFIG = [
    # 1. Load dimension tables first (no FK dependencies)
    (
        "olist_customers_dataset.csv",
        "olist_customers",
        {},
        [],
    ),
    (
        "olist_sellers_dataset.csv",
        "olist_sellers",
        {},
        [],
    ),
    (
        "olist_products_dataset.csv",
        "olist_products",
        # The raw CSV ships with two typos – correct them here
        {
            "product_name_lenght":        "product_name_length",
            "product_description_lenght": "product_description_length",
        },
        [],
    ),
    (
        "product_category_name_translation.csv",
        "product_category_name_translation",
        {},
        [],
    ),
    # 2. Geolocation – large file, still uses chunked Python loader here
    #    (Scala/Spark on Watson Studio is the alternative for cloud env)
    (
        "olist_geolocation_dataset.csv",
        "olist_geolocation",
        {},
        [],
    ),
    # 3. Load orders before its child tables
    (
        "olist_orders_dataset.csv",
        "olist_orders",
        {},
        [
            "order_purchase_timestamp",
            "order_approved_at",
            "order_delivered_carrier_date",
            "order_delivered_customer_date",
            "order_estimated_delivery_date",
        ],
    ),
    # 4. Child tables (depend on orders / products / sellers)
    (
        "olist_order_items_dataset.csv",
        "olist_order_items",
        {},
        ["shipping_limit_date"],
    ),
    (
        "olist_order_payments_dataset.csv",
        "olist_order_payments",
        {},
        [],
    ),
    (
        "olist_order_reviews_dataset.csv",
        "olist_order_reviews",
        {},
        ["review_creation_date", "review_answer_timestamp"],
    ),
]


# ============================================================
#  HELPERS
# ============================================================

def build_engine():
    """Create SQLAlchemy engine for MySQL via PyMySQL."""
    url = (
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}"
        f"@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        f"?charset=utf8mb4"
    )
    engine = create_engine(url, pool_pre_ping=True)
    log.info("Database engine created → %s:%s/%s", DB_HOST, DB_PORT, DB_NAME)
    return engine


def read_csv_safe(filepath: str, date_cols: list[str], renames: dict) -> pd.DataFrame:
    """
    Read a CSV with sensible defaults:
    - UTF-8 with latin-1 fallback (handles Brazilian accented characters)
    - Keep_default_na=True so empty cells become NaN (→ NULL in MySQL)
    - Parse known date columns immediately
    - Apply column renames (typo corrections)
    """
    try:
        df = pd.read_csv(
            filepath,
            encoding="utf-8",
            keep_default_na=True,
            low_memory=False,
        )
    except UnicodeDecodeError:
        log.warning("UTF-8 failed for %s – retrying with latin-1", os.path.basename(filepath))
        df = pd.read_csv(
            filepath,
            encoding="latin-1",
            keep_default_na=True,
            low_memory=False,
        )

    # Apply column renames (typo fixes)
    if renames:
        df.rename(columns=renames, inplace=True)
        log.info("  Renamed columns: %s", renames)

    # Parse date columns – coerce errors so bad strings become NaT (→ NULL)
    for col in date_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    log.info(
        "  Read %-45s  →  %7d rows × %d cols",
        os.path.basename(filepath),
        len(df),
        len(df.columns),
    )
    return df


def load_table_chunked(
    df: pd.DataFrame,
    table_name: str,
    engine,
    chunk_size: int = CHUNK_SIZE,
) -> int:
    """
    Push DataFrame to MySQL in chunks using pandas to_sql.
    - First chunk creates/replaces the table; subsequent chunks append.
    - Returns total rows inserted.
    """
    total_rows = len(df)
    n_chunks = (total_rows // chunk_size) + 1
    rows_loaded = 0

    for i, start in enumerate(
        tqdm(range(0, total_rows, chunk_size), desc=f"  Loading {table_name}", unit="chunk")
    ):
        chunk = df.iloc[start : start + chunk_size]
        if_exists = "append" 

        chunk.to_sql(
            name=table_name,
            con=engine,
            if_exists=if_exists,
            index=False,
            # dtype=None lets pandas infer; NaN → NULL automatically
            method="multi",     # batch INSERT – faster than row-by-row
        )
        rows_loaded += len(chunk)

    return rows_loaded


def verify_row_counts(engine, table_name: str, expected: int) -> bool:
    """Query MySQL row count and compare with expected (CSV row count)."""
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT COUNT(*) FROM `{table_name}`"))
        actual = result.scalar()
    match = actual == expected
    status = "✓ OK" if match else "✗ MISMATCH"
    log.info(
        "  Verify %-40s  expected=%7d  actual=%7d  %s",
        table_name,
        expected,
        actual,
        status,
    )
    return match


# ============================================================
#  MAIN PIPELINE
# ============================================================

def run_pipeline():
    start_time = time.time()
    log.info("=" * 60)
    log.info("E-ComInsight ELT Pipeline  –  START")
    log.info("=" * 60)

    engine = build_engine()
    expected_counts: dict[str, int] = {}

    # Disable FK checks so we can load tables in any order safely
    with engine.connect() as conn:
        conn.execute(text("SET FOREIGN_KEY_CHECKS = 0;"))
        conn.commit()
    log.info("Foreign key checks DISABLED for bulk load")

    # ── Load each table ──────────────────────────────────────
    for csv_file, table, renames, date_cols in TABLE_CONFIG:
        filepath = os.path.join(CSV_FOLDER, csv_file)

        if not os.path.exists(filepath):
            log.error("File not found: %s  – SKIPPING", filepath)
            continue

        log.info("")
        log.info("─── %s → %s ───", csv_file, table)

# ✅ ĐOẠN CODE MỚI ĐÃ SỬA DỨT ĐIỂM (Copy đoạn này dán đè vào dòng 269):
        df = read_csv_safe(filepath, date_cols, renames)
        
        # 1. Tự động xóa sạch dữ liệu cũ trong bảng trước khi nạp để tránh kẹt rác
        with engine.connect() as conn:
            conn.execute(text(f"DELETE FROM `{table}`;"))
            conn.commit()

        # 2. Xử lý bẫy trùng lặp khóa chính và dấu xuống dòng riêng cho bảng Reviews
        if table == "olist_order_reviews":
            log.info("  [Cleaning] Filtering duplicate review_ids and cleaning text...")
            # Lọc bỏ các dòng trùng review_id, chỉ giữ lại dòng đầu tiên
            df.drop_duplicates(subset=["review_id"], keep="first", inplace=True)
            # Ủi thẳng các dấu Enter xuống dòng trong comment để không làm vỡ câu lệnh SQL
            for col in ["review_comment_title", "review_comment_message"]:
                if col in df.columns:
                    df[col] = df[col].astype(str).str.replace(r'\n|\r', ' ', regex=True)

        expected_counts[table] = len(df)

        rows = load_table_chunked(df, table, engine)
        log.info("  Loaded %d rows into `%s`", rows, table)

    # Re-enable FK checks
    with engine.connect() as conn:
        conn.execute(text("SET FOREIGN_KEY_CHECKS = 1;"))
        conn.commit()
    log.info("")
    log.info("Foreign key checks RE-ENABLED")

    # ── Verification pass ────────────────────────────────────
    log.info("")
    log.info("=" * 60)
    log.info("VERIFICATION – Row count check")
    log.info("=" * 60)
    all_ok = True
    for table, expected in expected_counts.items():
        ok = verify_row_counts(engine, table, expected)
        if not ok:
            all_ok = False

    # ── Summary ──────────────────────────────────────────────
    elapsed = time.time() - start_time
    log.info("")
    log.info("=" * 60)
    if all_ok:
        log.info("ALL TABLES LOADED SUCCESSFULLY  ✓")
    else:
        log.warning("Some tables have row-count mismatches – check the log above")
    log.info("Total time: %.1f seconds (%.1f minutes)", elapsed, elapsed / 60)
    log.info("=" * 60)


if __name__ == "__main__":
    run_pipeline()
