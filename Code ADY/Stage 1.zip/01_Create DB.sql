-- ============================================================
-- E-ComInsight: Olist Database Schema
-- Project ADY201m  |  Stage 1 – Database Setup
-- Run this FIRST before executing the Python ELT script
-- ============================================================

CREATE DATABASE IF NOT EXISTS olist_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE olist_db;

-- Disable FK checks during setup so order of creation doesn't matter
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- 1. customers
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_customers;
CREATE TABLE olist_customers (
    customer_id             VARCHAR(50)  NOT NULL,
    customer_unique_id      VARCHAR(50)  NULL,
    customer_zip_code_prefix VARCHAR(10) NULL,
    customer_city           VARCHAR(100) NULL,
    customer_state          VARCHAR(5)   NULL,
    PRIMARY KEY (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 2. sellers
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_sellers;
CREATE TABLE olist_sellers (
    seller_id               VARCHAR(50)  NOT NULL,
    seller_zip_code_prefix  VARCHAR(10)  NULL,
    seller_city             VARCHAR(100) NULL,
    seller_state            VARCHAR(5)   NULL,
    PRIMARY KEY (seller_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 3. geolocation  (large file – loaded via Scala/Spark or chunked Python)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_geolocation;
CREATE TABLE olist_geolocation (
    geolocation_id          BIGINT       NOT NULL AUTO_INCREMENT,
    geolocation_zip_code_prefix VARCHAR(10) NULL,
    geolocation_lat         DOUBLE       NULL,
    geolocation_lng         DOUBLE       NULL,
    geolocation_city        VARCHAR(100) NULL,
    geolocation_state       VARCHAR(5)   NULL,
    PRIMARY KEY (geolocation_id),
    INDEX idx_geo_zip (geolocation_zip_code_prefix),
    INDEX idx_geo_state (geolocation_state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 4. products
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_products;
CREATE TABLE olist_products (
    product_id                   VARCHAR(50)  NOT NULL,
    product_category_name        VARCHAR(100) NULL,
    -- NOTE: source CSV has typo "product_name_lenght" – corrected in Python loader
    product_name_length          INT          NULL,
    product_description_length   INT          NULL,
    product_photos_qty           INT          NULL,
    product_weight_g             DOUBLE       NULL,
    product_length_cm            DOUBLE       NULL,
    product_height_cm            DOUBLE       NULL,
    product_width_cm             DOUBLE       NULL,
    PRIMARY KEY (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 5. product_category_name_translation
-- ------------------------------------------------------------
DROP TABLE IF EXISTS product_category_name_translation;
CREATE TABLE product_category_name_translation (
    product_category_name         VARCHAR(100) NOT NULL,
    product_category_name_english VARCHAR(100) NULL,
    PRIMARY KEY (product_category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 6. orders  (central hub table – links customers to everything)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_orders;
CREATE TABLE olist_orders (
    order_id                        VARCHAR(50)  NOT NULL,
    customer_id                     VARCHAR(50)  NULL,
    order_status                    VARCHAR(30)  NULL,
    order_purchase_timestamp        DATETIME     NULL,
    order_approved_at               DATETIME     NULL,
    order_delivered_carrier_date    DATETIME     NULL,
    order_delivered_customer_date   DATETIME     NULL,
    order_estimated_delivery_date   DATETIME     NULL,
    PRIMARY KEY (order_id),
    INDEX idx_order_customer (customer_id),
    INDEX idx_order_status   (order_status),
    INDEX idx_order_purchase (order_purchase_timestamp),
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES olist_customers (customer_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 7. order_items
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_order_items;
CREATE TABLE olist_order_items (
    order_id            VARCHAR(50)  NOT NULL,
    order_item_id       INT          NOT NULL,   -- line-item position within order
    product_id          VARCHAR(50)  NULL,
    seller_id           VARCHAR(50)  NULL,
    shipping_limit_date DATETIME     NULL,
    price               DECIMAL(10,2) NULL,
    freight_value       DECIMAL(10,2) NULL,
    PRIMARY KEY (order_id, order_item_id),
    INDEX idx_items_product (product_id),
    INDEX idx_items_seller  (seller_id),
    CONSTRAINT fk_items_order
        FOREIGN KEY (order_id)   REFERENCES olist_orders   (order_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_items_product
        FOREIGN KEY (product_id) REFERENCES olist_products (product_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_items_seller
        FOREIGN KEY (seller_id)  REFERENCES olist_sellers  (seller_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 8. order_payments
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_order_payments;
CREATE TABLE olist_order_payments (
    order_id                VARCHAR(50)  NOT NULL,
    payment_sequential      INT          NOT NULL,  -- multiple payments per order allowed
    payment_type            VARCHAR(30)  NULL,
    payment_installments    INT          NULL,
    payment_value           DECIMAL(10,2) NULL,
    PRIMARY KEY (order_id, payment_sequential),
    INDEX idx_payments_type (payment_type),
    CONSTRAINT fk_payments_order
        FOREIGN KEY (order_id) REFERENCES olist_orders (order_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 9. order_reviews
-- ------------------------------------------------------------
DROP TABLE IF EXISTS olist_order_reviews;
CREATE TABLE olist_order_reviews (
    review_id               VARCHAR(50)  NOT NULL,
    order_id                VARCHAR(50)  NULL,
    review_score            TINYINT      NULL,     -- 1 to 5 stars
    review_comment_title    VARCHAR(255) NULL,
    review_comment_message  TEXT         NULL,
    review_creation_date    DATETIME     NULL,
    review_answer_timestamp DATETIME     NULL,
    PRIMARY KEY (review_id),
    INDEX idx_reviews_order (order_id),
    INDEX idx_reviews_score (review_score),
    CONSTRAINT fk_reviews_order
        FOREIGN KEY (order_id) REFERENCES olist_orders (order_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Re-enable FK checks after all tables are created
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Quick sanity check – run after creation
-- ============================================================
SELECT table_name, table_rows
FROM   information_schema.tables
WHERE  table_schema = 'olist_db'
ORDER  BY table_name;